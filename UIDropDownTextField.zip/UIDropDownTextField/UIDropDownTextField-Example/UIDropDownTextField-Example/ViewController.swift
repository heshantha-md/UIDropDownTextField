//
//  ViewController.swift
//  UIDropDownTextField-Example
//
//  Created by Nadeeshan Jayawardana on 7/9/18.
//  Copyright © 2018 NEngineering. All rights reserved.
//

import UIKit

// Mark - Adding UIDropDownTextFieldDelegate to ViewController
//        So ViewController calss can access UIDropDownTextField delegate functions

class ViewController: UIViewController, UIDropDownTextFieldDelegate {
    
    // Mark - Declaring and initializing an empty UIDropDownObject array
    //        so later can set drop down items in UIDropDownTextFieldDelegate datasource
    
    var socialMediaList: [UIDropDownObject] = [UIDropDownObject]()
    
    // Mark - Declaring and initializing a IBOutlet UIDropDownTextField
    //        so an UITextField can hook from interface
    
    @IBOutlet var dropTextField: UIDropDownTextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Mark - Initializing a new UIDropDownObject with object using previous UIDropDownObject variable
        
        let facebook = UIDropDownObject(title: "Facebook", value: "Facebook", icon: UIImage.init(named: "ic_facebook"))
        let linkedin = UIDropDownObject(title: "Linked in", value: "Linked in", icon: UIImage.init(named: "ic_linkedin"))
        let twitter = UIDropDownObject(title: "Twitter", value: "Twitter", icon: UIImage.init(named: "ic_twitter"))
        let google = UIDropDownObject(title: "Google", value: "Google", icon: UIImage.init(named: "ic_google"))
        let blogger = UIDropDownObject(title: "Blogger", value: "Blogger", icon: UIImage.init(named: "ic_blogger"))
        let snapchat = UIDropDownObject(title: "Snapchat", value: "Snapchat", icon: UIImage.init(named: "ic_snapchat"))
        let github = UIDropDownObject(title: "Github", value: "Github", icon: UIImage.init(named: "ic_github"))
        socialMediaList = [facebook,linkedin,twitter,google,blogger,snapchat,github]
        
        dropTextField.dropDownDelegate = self
    }
    
    
    // Mark - UIDropDownTextFieldDelegate datasource functions
    
    func dropDownTextField(_ dropDownTextField: UIDropDownTextField, didSelectRowAt indexPath: IndexPath) {
        let aDropDownObject: UIDropDownObject = socialMediaList[indexPath.row];
        print("Great! You just select \(aDropDownObject.title) from UIDropDownTextField.")
        
        // Or
        
        print("Great! You can get selected text of \(dropTextField.text()) from UIDropDownTextField.")
        print("Great! You can get selected value of \(dropTextField.value()) from UIDropDownTextField.")
    }
    
    // Mark - Initializing drop down items in UIDropDownTextField datasource
    
    func dropDownTextField(_ dropDownTextField: UIDropDownTextField, setOfItemsInDropDownMenu items: [UIDropDownObject]) -> [UIDropDownObject] {
        return socialMediaList
    }
}

